<form action="greet.php" method="POST"/> 
    <label>Your name:</label>
    <input type="text" name="recipient_name" />
    <br/>
    
    <label>Select a greeting:</label>  
    <select name="select_greeting">  
    <?php
	    foreach ($data as $p)
        {   
            echo'<OPTION VALUE="'.$p['text'].'">'. $p['text'].'</OPTION>';
        }
    ?>
    </select>
    <label>Or create your own:</label>
    <input type="text" name="custom_greeting" />
    <br/>
    <input type="submit"/>
</form>
